#requires -Version 5.1

<#
Device and Display Asset Audit Tool

Collects: 
- Hostname 
- Manufacturer
- Model
- Model Number / System SKU
- Serial Number
- Chassis Type
- Processor details
- Memory details 
- Storage details 
- BIOS details 

#> 

Set-StrictMode -Version Latest
$ErrorActionPreference = "Continue"

Clear-Host 

$auditWarnings = @()

# ============================================================
# GENERAL HELPER FUNCTIONS
# ============================================================

function Write-SectionHeader {
    param(
        [Parameter(Mandatory)]
        [string]$Title
    )

    Write-Host ""
    Write-Host ("=" * 75) -ForegroundColor DarkCyan
    Write-Host $Title -ForegroundColor DarkCyan
    Write-Host ("=" * 75) -ForegroundColor DarkCyan
}

function Write-Field {
    param(
        [Parameter(Mandatory)]
        [string]$Label,

        [AllowNull()]
        [object]$Value
    )

    $displayValue = if (
        $null -eq $Value -or
        [string]::IsNullOrWhiteSpace([string]$Value)
    ) {
        "Not available"
    }
    else {
        [string]$Value
    }

    Write-Host ("{0,-30}: " -f $Label) -NoNewline -ForegroundColor Gray
    Write-Host $displayValue -ForegroundColor White
}

function Add-AuditWarning {
    param( 
        [Parameter(Mandatory)]
        [string]$Message
    )

    if (-not [string]::IsNullOrWhiteSpace($Message)) {
        if ($auditWarnings -notcontains $Message) {
            $script:auditWarnings += $Message
        }
    }
}

function Get-SafeCimInstance { 
    param(
        [Parameter(Mandatory)]
        [string]$ClassName,

        [string]$Namespace = "root\cimv2",

        [string]$Filter
    )

    try {
        if ([string]::IsNullOrWhiteSpace($Filter)) {
            return Get-CimInstance `
                -ClassName $ClassName `
                -Namespace $Namespace `
                -ErrorAction Stop
        }

        return Get-CimInstance `
            -ClassName $ClassName `
            -Namespace $Namespace `
            -Filter $Filter `
            -ErrorAction Stop
    }
    catch {
        Write-Warning (
            "Unable to read $ClassName information from " +
            "$Namespace`: $($_.Exception.Message)"
        )

        return $null
    }
}
function Convert-BytesToGB {
    param(
        [AllowNull()]
        [object]$Bytes
    )

    if ($null -eq $Bytes) {
        return "Not available"
    }

    try {
        return "{0:N2} GB" -f ([double]$Bytes / 1GB)
    } 
    catch {
        return "Not available"
    }
}

function Convert-KBToGB {
    param(
        [AllowNull()]
        [object]$Kilobytes
    )

    if ($null -eq $Kilobytes) {
        return "Not available"
    }

    try {
        return "{0:N2} GB" -f ([double]$Kilobytes / 1MB)
    }
    catch { 
        return "Not available"
    }
}

function Get-ChassisTypeName {
    param(
        [AllowNull()]
        [object[]]$ChassisTypes
    )

    if ($null -eq $ChassisTypes -or $ChassisTypes.Count -eq 0) {
        return "Not available"
    }

    $chassisMap = @{
        1 = "Other"
        2 = "Unknown"
        3 = "Desktop"
        4 = "Low Profile Desktop"
        5 = "Pizza Box"
        6 = "Mini Tower"
        7 = "Tower"
        8 = "Portable"
        9 = "Laptop"
        10 = "Notebook"
        11 = "Hand Held"
        12 = "Docking Station"
        13 = "All-in-One"
        14 = "Sub Notebook"
        15 = "Space-Saving"
        16 = "Lunch Box"
        17 = "Main System Chassis"
        18 = "Expansion Chassis"
        19 = "Sub Chassis"
        20 = "Bus Expansion Chassis"
        21 = "Peripheral Chassis"
        22 = "Storage Chassis"
        23 = "Rack Mount Chassis"
        24 = "Sealed-Case PC"
        30 = "Tablet"
        31 = "Convertible"
        32 = "Detachable"
        35 = "Mini PC"
        36 = "Stick PC"
    }

    $names = foreach ($type in $ChassisTypes) {
        $number = [int]$type

        if ($chassisMap.ContainsKey($number)) {
            $chassisMap[$number]
        }
        else {
            "Unknown Type ($number)"
        } 
    }

    return ($names -join ", ")
}

function  Get-MemoryTypeName {
    param(
        [AllowNull()]
        [object]$SmbiosMemoryType,

        [AllowNull()]
        [object]$LegacyMemoryType
    )

    $typeValue = 0

    if ($null -ne $SmbiosMemoryType -and [int]$SmbiosMemoryType -gt 0) {
        $typeValue = [int]$SmbiosMemoryType
    }
    elseif ($null -ne $LegacyMemoryType) {
        $typeValue = [int]$LegacyMemoryType
    }

    $memoryTypeMap = @{
        0  = "Unknown"
        1  = "Other"
        2  = "DRAM"
        3  = "Synchronous DRAM"
        4  = "Cache DRAM"
        5  = "EDO"
        6  = "EDRAM"
        7  = "VRAM"
        8  = "SRAM"
        9  = "RAM"
        10 = "ROM"
        11 = "Flash"
        12 = "EEPROM"
        13 = "FEPROM"
        14 = "EPROM"
        15 = "CDRAM"
        16 = "3DRAM"
        17 = "SDRAM"
        18 = "SGRAM"
        19 = "RDRAM"
        20 = "DDR"
        21 = "DDR2"
        22 = "DDR2 FB-DIMM"
        24 = "DDR3"
        25 = "FBD2"
        26 = "DDR4"
        27 = "LPDDR"
        28 = "LPDDR2"
        29 = "LPDDR3"
        30 = "LPDDR4"
        31 = "Logical Non-Volatile Device"
        32 = "HBM"
        33 = "HBM2"
        34 = "DDR5"
        35 = "LPDDR5"
    }
    
    if ($memoryTypeMap.ContainsKey($typeValue)) {
        return $memoryTypeMap[$typeValue]
    }

    return "Unknown Type ($typeValue)"
}

function Get-DriveTypeName {
    param(
        [AllowNull()]
        [object]$DriveType
    )

    $driveTypeMap = @{
        0 = "Unknown"
        1 = "No Root Directory"
        2 = "Removable Disk"
        3 = "Local Disk"
        4 = "Network Disk"
        5 = "Compact Disk"
        6 = "RAM Disk"
    }

    if ($null -eq $DriveType) {
        return "Not available"
    }

    $number = [int]$DriveType

    if ($driveTypeMap.ContainsKey($number)) {
        return $driveTypeMap[$number]
    }

    return "Unknown Type ($number)"
}

function Format-CimDate {
    param(
        [AllowNull()]
        [object]$DateValue
    )

    if ($null -eq $DateValue) {
        return "Not available"
    }

    try {
        return ([datetime]$DateValue).ToString("MM/dd/yyyy")
    }
    catch {
        return [string]$DateValue
    }
}

function Convert-EdidText { 
    param(
        [AllowNull()]
        [object[]]$CharacterCodes
    )

    if ($null -eq $CharacterCodes) {
        return "Not available"
    }

    try {
        $characters = foreach ($code in $CharacterCodes) {
            if ([int]$code -gt 0) {
                [char][int]$code
            }
        }

        $text = (-join $characters).Trim([char]0).Trim()

        if ([string]::IsNullOrWhiteSpace($text)) {
            return "Not avaiable"
        }

        return $text
    }
    catch { 
        return "Not avaibale"
    }
} 

function Get-BatteryStatusName {
    param(
        [object]$StatusCode
    )

    $statusMap = @{
        1  = "Discharging"
        2  = "Connected to AC Power"
        3  = "Fully Charged"
        4  = "Low"
        5  = "Critical"
        6  = "Charging"
        7  = "Charging and High"
        8  = "Charging and Low"
        9  = "Charging and Critical"
        10 = "Undefined"
        11 = "Partially Charged"
    }

    if ($null -eq $StatusCode) {
        return "Not available" 
    }

    $statusNumber = [int]$StatusCode

    if ($statusMap.ContainsKey($statusNumber)) {
        return $statusMap[$statusNumber]
    }

    return "Unknown Status ($statusNumber)" 
}

function Get-BatteryHealthRating {
    param(
        [object]$HealthPercent 
    )

    if ($null -eq $HealthPercent) {
        return "Not available"
    }

    $health = [double]$HealthPercent

    if ($health -ge 90) {
        return "Excellent"
    }
    elseif ($health -ge 80) {
        return "Good"
    }
    elseif ($health -ge 65) {
        return "Fair"
    }
    elseif ($health -ge 50) {
        return "Critical"
    }
}

# ============================================================ 
# COLLECT DEVICE INFORMATION
# ============================================================

Write-Host "Device and Display Asset Audit Tool" -ForegroundColor Cyan
Write-Host "Core Device Hardware Scan" -ForegroundColor DarkCyan
Write-Host ""
Write-Host "Scanning the local computer..." -ForegroundColor Yellow

$computerSystem = Get-SafeCimInstance -ClassName "Win32_ComputerSystem"
$computerProduct = Get-SafeCimInstance -ClassName "Win32_ComputerSystemProduct"
$systemEnclosure = Get-SafeCimInstance -ClassName "Win32_SystemEnclosure"
$processors = @(Get-SafeCimInstance -ClassName "Win32_Processor")
$memoryModules = @(Get-SafeCimInstance -ClassName "Win32_PhysicalMemory")
$memoryArrays = @(Get-SafeCimInstance -ClassName "Win32_PhysicalMemoryArray") 
$logicalDrives = @(Get-SafeCimInstance -ClassName "Win32_LogicalDisk" -Filter "DriveType = 3")
$diskDrives = @(Get-SafeCimInstance -ClassName "Win32_DiskDrive")
$bios = Get-SafeCimInstance -ClassName "Win32_BIOS"

$monitorIds = @(
    Get-SafeCimInstance `
        -ClassName "WmiMonitorID" `
        -Namespace "root\wmi"
)

$monitorDisplayParams = @(
    Get-SafeCimInstance `
    -ClassName "WmiMonitorBasicDisplayParams" `
    -Namespace "root\wmi"
)

$monitorConnectionParams = @(
    Get-SafeCimInstance `
    -ClassName "WmiMonitorConnectionParams" `
    -Namespace "root\wmi"
)

$monitorResults = @()
$monitorNumber = 1

foreach ($monitor in $monitorIds) {
    if ($null -eq $monitor) {
        continue 
    }

    $instanceName = $monitor.InstanceName

    $displayParams = $monitorDisplayParams |
        Where-Object {
            $_.InstanceName -eq $instanceName
        } |
        Select-Object -First 1

    $connectionParams = $monitorConnectionParams | 
        Where-Object {
            $_.InstanceName -eq $instanceName
        } |
        Select-Object -First 1

    $manufacturer = Convert-EdidText `
        -CharacterCodes $monitor.ManufacturerName 

    $model = Convert-EdidText `
        -CharacterCodes $monitor.UserFriendlyName 

    $serialNumber = Convert-EdidText `
        -CharacterCodes $monitor.SerialNumberID

    $widthCm = if (
        $null -ne $displayParams -and 
        $displayParams.PSObject.Properties.Name -contains "MaxHorizontalImageSize"
    ) {
        $displayParams.MaxHorizontalImageSize 
    }
    else {
        $null
    }

    $heightCm = if (
        $null -ne $displayParams -and
        $displayParams.PSObject.Properties.Name -contains "MaxVerticalImageSize"
    ) {
        $displayParams.MaxVerticalImageSize
    }
    else {
        $null
    }

    $screenSizeInches = if (
        $widthCm -and
        $heightCm
    ) {
        [math]::Round(
            (
                [math]::Sqrt(
                    ([math]::Pow([double]$widthCm, 2)) +
                    ([math]::Pow([double]$heightCm, 2))
                ) / 2.54
            ),
            1
        )
    }
    else {
        "Not avaiable"
    }

    $activeStatus = if (
        $monitor.PSObject.Properties.Name -contains "Active"
    ) {
        if ($monitor.Active) {
            "Yes"
        }
        else {
            "No"
        }
    }
    else {
        "Not avaibale"
    }

    $manufactureWeek = if (
        $monitor.PSObject.Properties.Name -contains "WeekOfManufacture"
    ) {
        $monitor.WeekOfManufacture 
    }
    else {
        "Not available"
    }

    $manufactureYear = if (
        $monitor.PSObject.Properties.Name -contains "YearOfManufacture"
    ) {
        $monitor.YearOfManufacture
    }
    else {
        "Not avaibale"
    }

    $connectionCode = if (
        $null -ne $connectionParams -and
        $connectionParams.PSObject.Properties.Name -contains "VideoOutputTechnology"
    ) {
        $connectionParams.VideoOutputTechnology
    }
    else {
        "Not available"
    }

    $monitorResults += [pscustomObject]@{
        MonitorNumber     = $monitorNumber
        InstanceName    = $instanceName 
        Active            = $activeStatus
        Manufacturer      = $manufacturer
        Model             = $model
        SerialNumber      = $serialNumber
        ManufactureWeek   = $manufactureWeek
        ManufactureYear   = $manufactureYear
        WidthCm           = $widthCm
        HeightCm          = $heightCm
        ScreenSizeInches  = $screenSizeInches
        ConnectionCode    = $connectionCode
    }

    $monitorNumber++
}         
        

try {
    $physicalDisks = @(Get-PhysicalDisk -ErrorAction Stop)
}
catch {
    $physicalDisks = @()
}

# ============================================================
# COLLECT WINDOWS INFORMATION
# ============================================================

$operatingSystem = Get-SafeCimInstance `
    -ClassName "Win32_OperatingSystem"

$windowsEdition = "Not available"
$windowsVersion = "not available"
$windowsBuild = "Not available"
$windowsArchitecture = "Not available"
$windowsInstallDate = "Not available"
$windowsLastBootTime = "Not available"
$windowsUpTime = "Not available"

if ($null -ne $operatingSystem) {
    if (
        $operatingSystem.PSObject.Properties.Name -contains "Caption"
    ) {
        $windowsEdition = $operatingSystem.Caption
    }

    if (
        $operatingSystem.PSObject.Properties.Name -contains "Version"
    ) {
        $windowsVersion = $operatingSystem.Version
    }

    if (
        $operatingSystem.PSObject.Properties.Name -contains "BuildNumber"
    ) {
        $windowsBuild = $operatingSystem.BuildNumber 
    }

    if (
        $operatingSystem.PSObject.Properties.Name -contains "OSArchitecture"
    ) {
        $windowsArchitecture = $operatingSystem.OSArchitecture
    }

    if (
        $operatingSystem.PSObject.Properties.Name -contains "InstallDate" -and
        $null -ne $operatingSystem.InstallDate
    ) {
        $windowsInstallDate = Format-CimDate `
            -DateValue $operatingSystem.InstallDate
    }

    if (
        $operatingSystem.PSObject.Properties.Name -contains "LastBootUpTime" -and
        $null -ne $operatingSystem.LastBootUpTime
    ) {
        try {
            $lastBootDate = [datetime]$operatingSystem.LastBootUpTime

            $windowsLastBootTime = $lastBootDate.ToString(
                "MM/dd/yyyy hh:mm:ss tt"
            )

            $uptimeSpan = (Get-Date) - $lastBootDate

            $windowsUptime = (
                "{0} days, {1} hours, {2} minutes" -f
                $uptimeSpan.Days,
                $uptimeSpan.Hours,
                $uptimeSpan.AddMinutes
            )
        }
        catch {
            $windowsLastBootTime = "Not available"
            $windowsUptime = "Not available"
        }
    }
}

$windowsInfo = [pscustomobject]@{
    Edition      = $windowsEdition
    Version      = $windowsVersion
    BuildNumber  = $windowsBuild
    Architecture = $windowsArchitecture
    InstallDate  = $windowsInstallDate
    LastBootTime = $windowsLastBootTime
    Uptime       = $windowsUptime 
} 

# ============================================================
# COLLECT BATTERY INFORMATION
# ============================================================

$win32Batteries = @(
    Get-SafeCimInstance `
        -ClassName "Win32_Battery"
)

$batteryStaticData = @(
    Get-SafeCimInstance `
        -ClassName "BatteryStaticData" `
        -Namespace "root\wmi"
)

$batteryFullChargeData = @(
    Get-SafeCimInstance `
        -ClassName "BatteryFullChargedCapacity" `
        -Namespace "root\wmi" 
)

$batteryCycleData = @(
    Get-SafeCimInstance `
        -ClassName "BatteryCycleCount" `
        -Namespace "root\wmi" 
)

$batteryResults = @()
$batteryNumber = 1

foreach ($battery in $win32Batteries) {
    if ($null -eq $battery) {
        continue 
    }

    $batteryIndex = $batteryNumber - 1

    $staticBattery = if (
        $batteryIndex -lt $batteryStaticData.Count 
    ) {
        $batteryStaticData[$batteryIndex]
    }
    else {
        $null 
    }

    $fullChargeBattery = if (
        $batteryIndex -lt $batteryFullChargeData.Count 
    ) {
        $batteryFullChargeData[$batteryIndex]
    }
    else {
        $null
    }

    $cycleBattery = if (
        $batteryIndex -lt $batteryCycleData.Count 
    ) {
        $batteryCycleData[$batteryIndex]
    }
    else {
        $null
    }

    $designCapacity = if (
        $null -ne $staticBattery -and 
        $staticBattery.PSObject.Properties.Name -contains
            "DesignedCapacity"
    ) {
        $staticBattery.DesignedCapacity 
    }
    elseif (
        $battery.PSObject.Properties.Name -contains
            "DesignCapacity"
    ) {
        $battery.DesignCapacity 
    }
    else {
        $null
    }

    $fullChargeCapacity = if (
        $null -ne $fullChargeBattery -and
        $fullChargeBattery.PSObject.Properties.Name -contains
            "FullChargedCapacity"
    ) {
        $fullChargeBattery.FullChargedCapacity 
    }
    elseif ( 
        $battery.PSObject.Properties.Name -contains 
            "FullChargeCapacity" 
    ) {
        $battery.FullchargeCapacity 
    }
    else {
        $null
    }

  $batteryHealthPercent = if (
      $designCapacity -and
      $fullChargeCapacity -and 
      [double]$designCapacity -gt 0
  ) {
      [math]::Round(
          (
               (
                  [double]$fullChargeCapacity /
                  [double]$designCapacity
               ) * 100
          ),
          2
      )
  }
  else {
    $null
  } 

    $cycleCount = if(
        $null -ne $cycleBattery -and
        $cycleBattery.PSObject.Properties.Name -contains
            "CycleCount"
    ) {
        $cycleBattery.CycleCount 
    }
    else {
        "Not available" 
    }

    $estimatedCharge = if (
        $battery.PSObject.Properties.Name -contains
            "EstimateChargeRemaining"
    ) {
        $battery.EstimatedChargeRemaining
    }
    else {
        $null
    }

    $batteryStatus = if (
        $battery.PSObject.Properties.Name -contains
            "Battery Status"
    ) {
        Get-BatteryStatusName `
            -StatusCode $battery.$batteryStatus
    }
    else {
        "Not available"
    }

    $batteryName = if (
        $battery.PSObject.Properties.Name -contains "Name"
    ) {
        $battery.Name
    }
    else {
        "Not available"
    }

    $batteryManufacturer = if (
        $battery.PSObject.Properties.Name -contains "Manufacturer"
    ) {
        $battery.Manufacturer
    }
    else {
        "Not available"
    }

    $batteryDeviceId = if (
        $battery.PSObject.Properties.Name -contains "DeviceID"
    ) {
        $battery.DeviceID
    }
    else {
        "Not available"
    }

    $batteryHealthRating = Get-BatteryHealthRating `
        -HealthPercent $batteryHealthPercent

    $batteryResults += [pscustomobject]@{
        BatteryNumber        = $batteryNumber 
        Name                 = $batteryName
        Manufacturer         = $batteryManufacturer
        DeviceID             = $batteryDeviceID
        EstimatedCharge      = $estimatedCharge
        Status               = $batteryStatus
        DesignCapacity       = $designCapacity
        FullChargeCapacity   = $fullChargeCapacity
        HealthPercent        = $batteryHealthPercent
        HealthRating         = $batteryHealthRating 
        CycleCount           = $cycleCount
    }

    $batteryNumber++
}

# ============================================================
# COLLECT NETWORK INFORMATION
# ============================================================

$networkConfigurations = @(
    Get-SafeCimInstance `
        -ClassName "Win32_NetworkAdapterConfiguration" `
        -Filter "IPEnabled = True"
)

$networkResults = @()
$networkNumber = 1

foreach ($networkConfig in $networkConfigurations) {
    if ($null -eq $networkConfig) {
        continue 
    } 

    $adapterIndex = $networkConfig.Index

    $networkAdapter = Get-SafeCimInstance `
        -ClassName "Win32_NetworkAdapter" `
        -Filter "Index = $adapterIndex"

    $adapterName = if (
        $null -ne $networkAdapter -and
        $networkAdapter.PSObject.Properties.Name -contains "Name"
    ) {
        $networkAdapter.Name
    }
    elseif (
        $networkConfig.PSObject.Properties.Name -contains "Description"
    ) {
        $networkConfig.Description
    }
    else {
        "Not available"
    } 

    $adapterDescription = if (
        $networkConfig.PSObject.Properties.Name -contains "Description"
    ) {
        $networkConfig.Description
    }
    else {
        "Not available"
    }

    $connectionStatus = if (
        $null -ne $networkAdapter -and 
        $networkAdapter.PSObject.Properties.Name -contains
            "NetConnectionStatus" 
    ) {
        switch ([int]$networkAdapter.NetConnectionStatus) {
            0  { "Disconnected" }
            1  { "Connecting" }
            2  { "Connected" }
            3  { "Disconnecting" }
            4  { "Hardware Not Present" }
            5  { "Hardware Disabled" }
            6  { "Hardware Malfunction" }
            7  { "Media Disconnected" }
            8  { "Authenticating" }
            9  { "Authentication Succeeded" }
            10 { "Authentication Failed" }
            11 { "Invalid Address" }
            12 { "Credentials Required" }
            default {
                "Unknown Status ($($networkAdapter.NetConnectionStatus))"
            }
        }
    }
    else {
        "Not available"
    }

    $ipv4Addresses = @()

    if (
        $networkConfig.PSObject.Properties.Name -contains "IPAddress" -and
        $null -ne $networkConfig.IPAddress
    ) {
        $ipv4Addresses = @(
            $networkConfig.IPAddress |
                Where-Object {
                    $_ -match "^\d{1,3}(\.\d{1,3}){3}$"
                }
        )
    } 

    $ipv6Addresses = @()

    if (
        $networkConfig.PSObject.Properties.Name -contains "IPAddress" -and 
        $null -ne $networkConfig.IPAddress
    ) {
        $ipv6Addresses = @(
            $networkConfig.IPAddress |
                Where-Object {
                    $_ -match ":"
                }
        )
    }

    $ipv4Display = if ($ipv4Addresses.Count -gt 0) {
        $ipv4Addresses -join ", "
    }
    else {
        "Not available"
    }

    $ipv6Display = if ($ipv6Addresses.Count -gt 0) {
        $ipv6Addresses -join ", "
    }
    else {
        "Not available"
    }

    $macAddress = if (
        $networkConfig.PSObject.Properties.Name -contains "MACAddress"
    ) {
        $networkConfig.MACAddress
    }
    else {
        "Not available"
    }

    $defaultGateway = if (
        $networkConfig.PSObject.Properties.Name -contains 
            "DefaultIPGateway" -and
        $null -ne $networkConfig.DefaultIPGateway
    ) {
        $networkConfig.DefaultIPGateway -join ", "
    }
    else {
        "Not available"
    }

    $dnsServers = if (
        $networkConfig.PSObject.Properties.Name -contains 
            "DNSServerSearchOrder" -and
        $null -ne $networkConfig.DNSServerSearchOrder
    ) {
        $networkConfig.DNSServerSearchOrder -join ", "
    }
    else {
        "Not available"
    }

    $dhcpEnabled = if (
        $networkConfig.PSObject.Properties.Name -contains "DHCP Enabled"
    ) {
        if ($networkConfig.DHCPEnabled) {
            "Yes"
        }
        else {
            "No"
        }
    }
    else {
        "Not available"
    }

    $wifiSsid = "Not availbale"

    try {
        $wlanOutput = netsh wlan show interfaces 2>$null

        $ssidLine = $wlanOutput |
            Where-Object {
                $_ -match "^\s*SSID\s*:" -and
                $_ -notmatch "BSSID"
            } |
            Select-Object -First 1
        if ($ssidLine) {
            $wifiSsid = (ssidLine -split ":", 2)[1].Trim()
        }
    }
    catch {
        $wifiSsid = "Not available"
    }

    $networkResults += [pscustomobject]@{
        NetworkNumber      = $networkNumber
        AdapterName        = $adapterName
        Description        = $adapterDescription
        ConnectionStatus   = $connectionStatus
        IPv4Address        = $ipv4Display
        IPv6Address        = $ipv6Display
        MACAddress         = $macAddress
        DefaultGateway     = $defaultGateway
        DNSServers         = $dnsServers
        DHCPEnabled        = $dhcpEnabled
        WiFiSSID           = $wifiSsid 
    }

    $networkNumber++
} 

# ============================================================
# AUTOMATED AUDIT WARNING CHECKS
# ============================================================

if (
    [string]::IsNullOrWhiteSpace([string]$serialNumber) -or
    $serialNumber -eq "Not available"
) {
    Add-AuditWarning `
        -Message "The device serial number is unavailable."
}

if (
    [string]::IsNullOrWhiteSpace([string]$manufacturer) -or
    $manufacturer -eq "Not available"
) {
    Add-AuditWarning `
        -Message "The device manufacturer is unavailable."
}

if (
    [string]::IsNullOrWhiteSpace([string]$model) -or
    $model -eq "Not available"
) {
    Add-AuditWarning `
        -Message "The device model is unavailable."
}

foreach ($logicalDrive in $logicalDrives) {
    if ($null -eq $logicalDrive) {
        continue 
    }

    if (
        $null -ne $logicalDrive.Size -and
        $null -ne $logicalDrive.FreeSpace -and 
        [double]$logicalDrive.Size -gt 0
    ) {
        $freeSpacePercent = [math]::Round(
            (
                ([double]$logicalDrive.FreeSpace /
                [double]$logicalDrive.Size) * 100
            ),
            2
        )

        if ($freeSpacePercent -lt 15) {
            Add-AuditWarning `
                -Message (
                    "Low disk space drive " +
                    "$($logicalDrive.DeviceID): " +
                    "$freeSpacePercent% free."
                )
        }
    }
}

foreach ($physicalDisk in $physicalDisks) {
    if ($null -eq $physicalDisk) {
        continue 
    }

    $physicalDiskName = if (
        $physicalDisk.PSObject.Properties.Name -contains "FriendlyName"
    ) {
        $physicalDisk.FriendlyName
    } 
    else {
        "Unknown physical drive"
    }

    $physicalDiskHealth = if (
        $physicalDisk.PSObject.Properties.Name -contains "HealthStatus"
    ) {
        [string]$physicalDisk.HealthStatus
    }
    else {
        "Not available"
    }

    if (
        $physicalDiskHealth -ne "Healthy" -and
        $physicalDiskHealth -ne "Not available"
    ) {
        Add-AuditWarning `
            -Message (
                "Drive health requires review for " +
                "$physicalDiskName. Status: " +
                "$physicalDiskHealth."
            )
    }
}

foreach ($batteryResult in $batteryResults) {
    if ($null -eq $batteryResult) {
        continue 
    }

    if ($null -ne $batteryResult.HealthPercent) {
        $batteryHealthValue = [double]$batteryResult.HealthPercent

        if ($batteryHealthValue -lt 65) {
            Add-AuditWarning `
                -Message (
                    "Battery $($batteryResult.BatteryNumber) " +
                    "health is low at " +
                    "$batteryHealthValue%."
                )
        }
    }
}

foreach ($monitorResult in $monitorResults) {
    if ($null -eq $monitorResult) {
        continue 
    }

    if (
        [string]::IsNullOrWhiteSpace(
            [string]$monitorResult.Model
        ) -or 
        $monitorResult.Model -eq "Not available"
    ) {
        Add-AuditWarning `
            -Message (
                "Display $($monitorResult.MonitorNumber) " +
                "model information is unavailable."
            )
    }

    if (
        [string]::IsNullOrWhiteSpace(
            [string]$monitorResult.SerialNumber 
        ) -or 
        $monitorResult.SerialNumber -eq "Not available" -or
        $monitorResult.SerialNumber -eq "0"
    ) {
        Add-AuditWarning `
            -Message (
                "Display $($monitorResult.MonitorNumber) " +
                "serial number is unavailable."
            )
    }
}

if ($monitorResults.Count -eq 0) {
    Add-AuditWarning `
        -Message "No monitor or display EDID information was detected."
} 

# ============================================================
# CALCULATE OVERALL AUDIT STATUS
# ============================================================

$warningCount = $auditWarnings.Count

if ($warningCount -eq 0) {
    $overallAuditStatus = "Passed"
    $overallAuditMessage = "No automated hardware inventory warnings were found."
}
elseif ($warningCount -le 2) {
    $overallAuditStatus = "Review Recommended"
    $overallAuditMessage = (
        "The scan completed successfully, but one or more " +
        "inventory details should be reviewed."
    )
}
else {
    $overallAuditStatus = "Attention Required"
    $overallAuditMessage = (
        "The scan completed, but multiple hardware or " +
        "inventory warnings require review."
    ) 
}
    
# ============================================================
# DEVICE IDENTIFICATION
# ============================================================

Write-SectionHeader -Title "DEVICE IDENTIFICATION"  

$hostname = $env:COMPUTERNAME
$manufacturer = $computerSystem.Manufacturer
$model = $computerSystem.Model
$modelNumber = $computerProduct.Version
$systemSku = $computerSystem.SystemSKUNumber
$serialNumber = $bios.SerialNumber
$loggedInUser = $computerSystem.UserName
$chassisType = Get-ChassisTypeName -ChassisTypes $systemEnclosure.ChassisTypes
$scanDate = Get-Date -Format "MM/dd/yyyy hh:mm:ss tt"

Write-Field -Label "Hostname" -Value $hostname
Write-Field -Label "Logged-In User" -Value $loggedInUser
Write-Field -Label "Manufacturer" -Value $manufacturer
Write-Field -Label "Model" -Value $model
Write-Field -Label "Model Number / Version" -Value $modelNumber
Write-Field -Label "System SKU" -Value $systemSku
Write-Field -Label "Serial Number" -Value $serialNumber
Write-Field -Label "Chassis Type" -Value $chassisType
Write-Field -Label "Scan Date and Time" -Value $scanDate

# ============================================================
# PROCESSOR INFORMATION
# ============================================================

Write-SectionHeader -Title "PROCESSOR INFORMATION"

$processorCount = $processors.Count

Write-Field -Label "Processor Count" -Value $processorCount

if ($processorCount -eq 0) {
    Write-Host "No processor information was detected." -ForegroundColor Yellow
}
else {
    $processorNumber = 1

    foreach ($processor in $processors) {
        Write-Host ""
        Write-Host "Processor $processorNumber" -ForegroundColor Green
        Write-Host ("-" * 40) -ForegroundColor DarkGray

        $processorSpeedGHz = if ($processor.MaxClockSpeed) {
            "{0:N2} GHz" -f ([double]$processor.MaxClockSpeed / 1000)
        }
        else {
            "Not available"
        }

        $currentSpeedGHz = if ($processor.CurrentClockSpeed) {
            "{0:N2} GHz" -f ([double]$processor.CurrentClockSpeed / 1000)
        }
        else {
            "Not available" 
        } 

        $supports64Bit = if ($processor.AddressWidth -eq 64) {
            "Yes"
        }
        elseif ($processor.AddressWidth -eq 32) {
            "No - 32-bit"
        }
        else {
            "Not avaibale"
        } 

        Write-Field -Label "Processor Details" -Value $processor.Name 
        Write-Field -Label "Manufacturer" -Value $processor.Manufacturer
        Write-Field -Label "Maximum Speed" -Value $processorSpeedGHz
        Write-Field -Label "Current Speed" -Value $currentSpeedGHz
        Write-Field -Label "Processor 64-Bit" -Value $supports64Bit
        Write-Field -Label "Processor Cores" -Value $processor.NumberofCores
        Write-Field -Label "Logical Processors" -Value $processor.NumberOfLogicalProcessors
        Write-Field -Label "Socket Designation" -Value $processor.SocketDesignation
        Write-Field -Label "Architecture Code" -Value $processor.Architecture

        $processorNumber++

    }
} 

# ============================================================
# MEMORY INFORMATION
# ============================================================ 

Write-SectionHeader -Title "MEMORY INFORMATION"

$totalMemory = if ($computerSystem.TotalPhysicalMemory) {
    Convert-BytesToGB -Bytes $computerSystem.TotalPhysicalMemory
}
else {
    "Not available"
}

$totalSlots = 0

foreach ($memoryArray in $memoryArrays) {
    if ($null -ne $memoryArray.MemoryDevices) {
        $totalSlots += [int]$memoryArray.MemoryDevices
    }
}

$usedSlots = $memoryModules.Count
$availableSlots = if ($totalSlots -ge $usedSlots) {
    $totalSlots - $usedSlots
}
else {
    0
}

Write-Field -Label "Total Installed Memory" -Value $totalMemory
Write-Field -Label "Total Memory Slots" -Value $totalSlots
Write-Field -Label "Used Memory Slots" -Value $usedSlots
Write-Field -Label "Available Memory Slots" -Value $availableSlots

if ($memoryModules.Count -eq 0) {
    Write-Host ""
    Write-Host "No individual memory module information was detected." -ForegroundColor Yellow
}
else {
    $moduleNumber = 1

    foreach ($module in $memoryModules) {
        Write-Host ""
        Write-Host "Memory Module $moduleNumber" -ForegroundColor Green
        Write-Host ("-" * 40) -ForegroundColor DarkGray

        $memoryType = Get-MemoryTypeName `
            -SmbiosMemoryType $module.SMBIOSMemoryType `
            -LegacyMemoryType $module.MemoryType

        $memorySpeed = if ($module.ConfiguredClockSpeed) {
            "$($module.ConfiguredClockSpeed) MHz"
        }
        elseif ($module.Speed) {
            "$($module.Speed) MHz"
        }
        else {
            "Not available"
        }

        Write-Field -Label "Slot / Device Locator" -Value $module.DeviceLocator
        Write-Field -Label "Bank Label" -Value $module.BankLabel
        Write-Field -Label "Capacity" -Value (Convert-BytesToGB -Bytes $module.Capacity)
        Write-Field -Label "Memory Type" -Value $memoryType
        Write-Field -Label "Memory Speed" -Value $memorySpeed
        Write-Field -Label "Manufacturer" -Value $module.Manufacturer
        Write-Field -Label "Part Number" -Value $module.PartNumber
        Write-Field -Label "Serial Number" -Value $module.SerialNumber

        $moduleNumber++
    }
}

# ============================================================
# LOGICAL DRIVE INFORMATION
# ============================================================

Write-SectionHeader -Title "LOGICAL DRIVE INFORMATION"

if ($logicalDrives.Count -eq 0) {
    Write-Host "No local logical drives were detected." -ForegroundColor Yellow
}
else {
    $logicalDriveNumber = 1

    foreach ($drive in $logicalDrives) {
        Write-Host ""
        Write-Host "Logical Drive $logicalDriveNumber" -ForegroundColor Green 
        Write-Host ("-" * 40) -ForegroundColor DarkGray

        $usedSpace = if ($null -ne $drive.Size -and $null -ne $drive.FreeSpace) {
            [double]$drive.Size - [double]$drive.FreeSpace
        }
        else {
            $null
        }

        Write-Field -Label "Drive Name" -Value $drive.DeviceID
        Write-Field -Label "Volume Name" -Value $drive.VolumeName 
        Write-Field -Label "Drive Capacity" -Value (Convert-BytesToGB -Bytes $drive.Size)
        Write-Field -Label "Used Space" -Value (Convert-BytesToGB -Bytes $usedSpace)
        Write-Field -Label "Free Space" -Value (Convert-BytesToGB -Bytes $drive.FreeSpace)
        Write-Field -Label "Drive Type" -Value (Get-DriveTypeName -DriveType $drive.DriveType)
        Write-Field -Label "File System" -Value $drive.FileSystem

        $logicalDriveNumber++
    }
}

# ============================================================
# PHYSICAL DRIVE INFORMATION
# ============================================================

Write-SectionHeader -Title "PHYSICAL DRIVE INFORMATION"

if ($diskDrives.Count -eq 0) {
    Write-Host "No physical drives were detected." -ForegroundColor Yellow
}
else {
    $physicalDriveNumber = 1

    foreach ($disk in $diskDrives) {
        Write-Host ""
        Write-Host "Physical Drive $physicalDriveNumber" -ForegroundColor Green
        Write-Host ("-" * 40) -ForegroundColor DarkGray

        $matchingPhysicalDisk = $physicalDisks |
            Where-Object {
                $_.FriendlyName -eq $disk.Model -or
                $_.SerialNumber -eq $disk.SerialNumber
            } | 
            Select-Object -First 1
        
        $mediaType = if ($matchingPhysicalDisk) {
            $matchingPhysicalDisk.MediaType
        }
        else {
            $disk.MediaType
        }

        $busType = if ($matchingPhysicalDisk) {
            $matchingPhysicalDisk.BusType
        }
        else {
            $disk.InterfaceType
        }

        $healthStatus = if ($matchingPhysicalDisk) {
            $matchingPhysicalDisk.HealthStatus
        }
        else {
            $disk.Status
        } 

        Write-Field -Label "Drive Name / Model" -Value $disk.Model
        Write-Field -Label "Manufacturer" -Value $disk.Manufacturer
        Write-Field -Label "Serial Number" -Value $disk.SerialNumber
        Write-Field -Label "Drive Capacity" -Value (Convert-BytesToGB -Bytes $disk.Size)
        Write-Field -Label "Drive Type / Media" -Value $mediaType
        Write-Field -Label "Bus / Interface Type" -Value $busType
        Write-Field -Label "Partitions" -Value $disk.Partitions
        Write-Field -Label "Health Status" -Value $healthStatus

        $physicalDriveNumber++
    }
}

# ============================================================
# BIOS INFORMATION
# ============================================================

Write-SectionHeader -Title "BIOS INFORMATION"

Write-Field -Label "BIOS Manufacturer" -Value $bios.Manufacturer
Write-Field -Label "BIOS Name" -Value $bios.Name
Write-Field -Label "BIOS Version" -Value $bios.SMBIOSBIOSVersion
Write-Field -Label "BIOS Serial Number" -Value $bios.SerialNumber
Write-Field -Label "BIOS Release Date" -Value (Format-CimDate -DateValue $bios.ReleaseDate)
Write-Field -Label "SMBIOS Version" -Value $bios.SMBIOSMajorVersion
Write-Field -Label "BIOS Status" -Value $bios.Status

# ============================================================
# DISPLAY AND MONITOR INFORMATION
# ============================================================

Write-SectionHeader -Title "DISPLAY AND MONITOR INFORMATION"

$detectedMonitorCount = $monitorResults.Count

Write-Field -Label "Display Detected" -Value $detectedMonitorCount

if ($detectedMonitorCount -eq 0) {
    Write-Field `
        -Label "Monitor Status" `
        -Value "No monitor EDID data detected"
    
    Write-Host ""
    Write-Host (
        "The computer may be using only a built-in display, " +
        "or the display hardware did not expose monitor data."
    ) -ForegroundColor Yellow
}
else {
    foreach ($monitorResult in $monitorResults) {
        Write-Host ""
        Write-Host "Display $($monitorResult.MonitorNumber)" `
            -ForegroundColor Green

        Write-Host ("-" * 40) -ForegroundColor DarkGray

        Write-Field `
            -Label "Active" `
            -Value $monitorResult.Active

        Write-Field `
            -Label "Manufacturer" `
            -Value $monitorResult.Manufacturer

        Write-Field `
            -Label "Model" `
            -Value $monitorResult.Model

        Write-Field `
            -Label "Serial Number" `
            -Value $monitorResult.SerialNumber

        Write-Field `
            -Label "Manufacture Week" `
            -Value $monitorResult.ManufactureWeek

        Write-Field `
            -Label "Manufacture Year" `
            -Value $monitorResult.ManufactureYear

        $widthDisplay = if ($monitorResult.WidthCm) {
            "$($monitorResult.WidthCm) cm" 
        }
        else {
            "Not available" 
        } 

        $heightDisplay = if ($monitorResult.HeightCm) {
            "$($monitorResult.HeightCm) cm"
        }
        else {
            "Not available"
        }

        $screenSizeDisplay = if (
            $monitorResult.ScreenSizeInches -ne "Not available"
        ) {
            "$($monitorResult.ScreenSizeInches) inches"
        }
        else {
            "Not available"
        }

        Write-Field `
            -Label "Width" `
            -Value $widthDisplay

        Write-Field `
            -Label "Height" `
            -Value $heightDisplay

        Write-Field `
            -Label "Approximate Screen Size" `
            -Value $screenSizeDisplay

        Write-Field `
            -Label "Connection Code" `
            -Value $monitorResult.ConnectionCode
    }
} 

# ============================================================
# WINDOWS INFORMATION
# ============================================================

Write-SectionHeader -Title "WINDOWS INFORMATION"

Write-Field `
    -Label "Windows Edition" `
    -Value $windowsInfo.Edition

Write-Field `
    -Label "Windows Version" `
    -Value $windowsInfo.Version

Write-Field `
    -Label "OS Build Number" `
    -Value $windowsInfo.BuildNumber

Write-Field `
    -Label "System Architecture" `
    -Value $windowsInfo.Architecture

Write-Field `
    -Label "Windows Install Date" `
    -Value $windowsInfo.InstallDate

Write-Field `
    -Label "Last Boot Time" `
    -Value $windowsInfo.LastBootTime

Write-Field `
    -Label "System Uptime" `
    -Value $windowsInfo.Uptime

# ============================================================
# BATTERY INFORMATION
# ============================================================

Write-SectionHeader -Title "BATTERY INFORMATION"

$batteryCount = $batteryResults.count

if ($batteryCount -eq 0) {
    Write-Field `
        -Label "Battery Detected" `
        -Value "No"

    Write-Host ""
    Write-Host (
        "No battery was detected. This may be a desktop " +
        "computer or a system that does not expose battery data."
    ) -ForegroundColor Yellow 
}
else {
    Write-Field `
        -Label "Battery Detected" `
        -Value "Yes"

    Write-Field `
        -Label "Battery Count" `
        -Value $batteryCount

    foreach ($batteryResult in $batteryResults) {
        Write-Host ""
        Write-Host "Battery $($batteryResult.BatteryNumber)" `
            -ForegroundColor Green .\DeviceDisplayAssetAudit.ps1

        Write-Host ("-" * 40) -ForegroundColor DarkGray

        Write-Field `
            -Label "Battery Name" `
            -Value $batteryResult.Name 

        Write-Field `
            -Label "Manufacturer" `
            -Value $batteryResult.Manufacturer

        Write-Field `
            -Label "Device ID" `
            -Value $batteryResult.DeviceID

        $chargeDisplay = if (
            $null -ne $batteryResult.EstimatedCharge
        ) {
            "$($batteryResult.EstimatedCharge)%" 
        }
        else {
            "Not available"
        }

        Write-Field `
            -Label "Estimated Charge" `
            -Value $chargeDisplay
        
        Write-Field `
            -Label "Battery Status" `
            -Value $batteryResult.Status
        
        $designCapacityDisplay = if (
            $batteryResult.DesignCapacity
        ) {
            "$($batteryResult.DesignCapacity) mWh"
        }
        else {
            "Not available"
        }

        $fullChargeDisplay = if (
            $batteryResult.FullChargeCapacity 
        ) {
            "$($batteryResult.FullChargeCapacity) mWh"
        }
        else {
            "Not available" 
        } 

        $healthDisplay = if (
            $null -ne $batteryResult.HealthPercent 
        ) {
            "$($batteryResult.HealthPercent)%"
        }
        else {
            "Not available"
        }

        Write-Field `
            -Label "Design Capacity" `
            -Value $designCapacityDisplay
        
        Write-Field `
            -Label "Full-Charge Capacity" `
            -Value $fullChargeDisplay 

        Write-Field `
            -Label "Battery Health" `
            -Value $healthDisplay

        Write-Field `
            -Label "Health Rating" `
            -Value $batteryResult.HealthRating

        Write-Field `
            -Label "Cycle Count" `
            -Value $batteryResult.CycleCount 
    }
}  

# ============================================================
# NETWORK INFORMATION
# ============================================================

Write-SectionHeader -Title "NETWORK INFORMATION"

$networkCount = $networkResults.count

Write-Field `
    -Label "Active Network Adapters" `
    -Value $networkCount

if ($networkCount -eq 0) {
    Write-Field `
        -Label "Network Status" `
        -Value "No IP-enabled network adapters detected"
}
else {
    foreach ($networkResult in $networkResults) {
        Write-Host ""
        Write-Host "Network Adapter $($networkResult.NetworkNumber)" `
            -ForegroundColor Green .\DeviceDisplayAssetAudit.ps1
        
        Write-Host ("-" *40) -ForegroundColor DarkGray

        Write-Field `
            -Label "Adapter Name" `
            -Value $networkResult.AdapterName
        
        Write-Field `
            -Label "Description" `
            -Value $networkResult.Description

        Write-Field `
            -Label "Connection Status" `
            -Value $networkResult.ConnectionStatus

        Write-Field `
            -Label "IPv4 Address" `
            -Value $networkResult.IPv4Address

        Write-Field `
            -Label "IPv6 Address" `
            -Value $networkResult.IPv6Address

        Write-Field `
            -Label "MAC Address" `
            -Value $networkResult.MACAddress

        Write-Field `
            -Label "Default Gateway" `
            -Value $networkResult.DefaultGateway

        Write-Field `
            -Label "DNS Servers" `
            -Value $networkResult.DNSServers

        Write-Field `
            -Label "DHCP Enabled" `
            -Value $networkResult.DHCPEnabled

        Write-Field `
            -Label "Wi-Fi SSID" `
            -Value $networkResult.WiFiSSID
    }
}

# ============================================================
# AUTOMATED AUDIT WARNINGS
# ============================================================

Write-SectionHeader -Title "AUTOMATED AUDIT WARNINGS"

$warningCount = $auditWarnings.Count

Write-Field `
    -Label "Warnings Found" `
    -Value $warningCount

if ($warningCount -eq 0) {
    Write-Host ""
    Write-Host "No automated audit warnings were found." `
        -ForegroundColor Green .\DeviceDisplayAssetAudit.ps1
}
else {
    Write-Host ""
    
    $warningNumber = 1

    foreach ($warning in $auditWarnings) {
        Write-Host (
            "$warningNumber. $warning"
        ) -ForegroundColor Yellow

        $warningNumber++
    }
}

# ============================================================
# OVERALL AUDIT SUMMARY
# ============================================================

Write-SectionHeader -Title "OVERALL AUDIT SUMMARY"

Write-Field `
    -Label "Computer Name" `
    -Value $env:COMPUTERNAME

Write-Field `
    -Label "Device Serial Number" `
    -Value $serialNumber

Write-Field `
    -Label "Displays Detected" `
    -Value $monitorResults.count

Write-Field `
    -Label "Batteries Detected" `
    -Value $batteryResults.Count 

Write-Field `
    -Label "Network Adapters Detected" `
    -Value $networkResults.Count 

Write-Field `
    -Label "Warnings Found" `
    -Value $warningCount 

Write-Host ""

$statusColor = switch ($overallAuditStatus) {
    "Passed" {
        "Green"
    }

    "Review Recommended" {
        "Yellow"
    }

    "Attention Required" {
        "Red"
    }

    default {
        "White"
    }
}

Write-Host ("{0,-30}: " -f "Overall Audit Status") `
    -NoNewline `
    -ForegroundColor Gray

Write-Host $overallAuditStatus `
    -ForegroundColor $statusColor

Write-Field `
    -Label "Summary" `
    -Value $overallAuditMessage 

# ============================================================
# STORE RESULTS FOR LATER PHASES
# ============================================================

$script:AuditData = [ordered]@{
    ScanDateTime = $scanDate

    Device = [ordered]@{
        Hostname           = $hostname
        LoggedInUser       = $loggedInUser
        Manufacturer       = $manufacturer
        Model              = $model
        ModelNumber        = $modelNumber
        SystemSKU          = $systemSku
        SerialNumber       = $serialNumber
        ChassisType        = $chassisType
    }

    Processors = $processors
    MemoryModules = $memoryModules
    LogicalDrives = $logicalDrives
    PhysicalDrives = $diskDrives
    BIOS = $bios
    Windows = $windowsInfo
    Batteries = $batteryResults
    BatteryCount = $batteryResults.Count 
    Networks = $networkResults
    NetworkCount = $networkResults.Count
    Monitors = $monitorResults
    MonitorCount = $monitorResults.Count
    AuditWarnings = $auditWarnings
    WarningCount = $warningCount 
    OverallAuditStatus = $overallAuditStatus
    OverallAuditMessage = $overallAuditMessage
}

# ============================================================
# BASIC TXT REPORT CREATION
# ============================================================

$txtReportFolder = Join-Path -Path $PSScriptRoot -ChildPath "Reports\TXT"

if (-not (Test-Path -Path $txtReportFolder)) {
    New-Item -Path $txtReportFolder -ItemType Directory -Force | Out-Null
}

$reportTimestamp = Get-Date -Format "yyyy-MM-dd_HHmmss"
$safeComputerName = $env:COMPUTERNAME -replace '[\\/:*?"<>|]', "_"
$txtReportFileName = "${safeComputerName}_DeviceAudit_${reportTimestamp}.txt"
$txtReportPath = Join-Path -Path $txtReportFolder -ChildPath $txtReportFileName

$txtReportLines = @(
    "======================================================================"
    "DEVICE AND DISPLAY ASSET AUDIT REPORT"
    "======================================================================"
    ""
    ("Report Generated             : {0}" -f (Get-Date -Format "yyyy-MM-dd HH:mm:ss"))
    ("Computer Name                : {0}" -f $env:COMPUTERNAME)
    ("Device Serial Number         : {0}" -f $serialNumber)
    ("Displays Detected            : {0}" -f $monitorResults.Count)
    ("Batteries Detected           : {0}" -f $batteryResults.Count)
    ("Network Adapters Detected    : {0}" -f $networkResults.Count)
    ("Warnings Found               : {0}" -f $warningCount)
    ("Overall Audit Status         : {0}" -f $overallAuditStatus)
    ("Summary                      : {0}" -f $overallAuditMessage)
    ""
    "======================================================================"
    "END OF BASIC REPORT"
    "======================================================================"
)

# ============================================================
# ADD DEVICE, WINDOWS, AND BIOS SECTIONS TO TXT REPORT
# ============================================================

$txtSectionsToAdd = @(
    @{
        Title = "DEVICE IDENTIFICATION"
        Data  = $script:AuditData["Device"]
    },
    @{
        Title = "WINDOWS INFORMATION"
        Data  = $script:AuditData["Windows"]
    },
    @{
        Title = "BIOS INFORMATION"
        Data  = $script:AuditData["BIOS"]
    }
)

foreach ($txtSection in $txtSectionsToAdd) {
    $txtReportLines += ""
    $txtReportLines += "----------------------------------------------------------------------"
    $txtReportLines += $txtSection.Title
    $txtReportLines += "----------------------------------------------------------------------"

    $sectionData = $txtSection.Data

    if ($null -eq $sectionData) {
        $txtReportLines += "Information not available."
        continue
    }

    if ($sectionData -is [System.Collections.IDictionary]) {
        foreach ($key in $sectionData.Keys) {
            $value = $sectionData[$key]

            if (
                $null -eq $value -or
                [string]::IsNullOrWhiteSpace([string]$value)
            ) {
                $value = "Not available"
            }

            $txtReportLines += (
                "{0,-30}: {1}" -f $key, $value
            )
        }
    }
    else {
        foreach ($property in $sectionData.PSObject.Properties) {
            $value = $property.Value

            if (
                $null -eq $value -or
                [string]::IsNullOrWhiteSpace([string]$value)
            ) {
                $value = "Not available"
            }

            $txtReportLines += (
                "{0,-30}: {1}" -f $property.Name, $value
            )
        }
    }
}

# ============================================================
# ADD PROCESSOR, MEMORY, AND DRIVE SECTIONS TO TXT REPORT
# ============================================================

$hardwareSectionsToAdd = @(
    @{
        Title = "PROCESSOR INFORMATION"
        Data  = $script:AuditData["Processors"]
    },
    @{
        Title = "MEMORY INFORMATION"
        Data  = $script:AuditData["Memory"]
    },
    @{
        Title = "LOGICAL DRIVE INFORMATION"
        Data  = $script:AuditData["LogicalDrives"]
    },
    @{
        Title = "PHYSICAL DRIVE INFORMATION"
        Data  = $script:AuditData["PhysicalDisks"]
    }
)

foreach ($hardwareSection in $hardwareSectionsToAdd) {
    $txtReportLines += ""
    $txtReportLines += "----------------------------------------------------------------------"
    $txtReportLines += $hardwareSection.Title
    $txtReportLines += "----------------------------------------------------------------------"

    $sectionData = $hardwareSection.Data

    if ($null -eq $sectionData) {
        $txtReportLines += "Information not available."
        continue
    }

    $sectionItems = @($sectionData)

    if ($sectionItems.Count -eq 0) {
        $txtReportLines += "None detected."
        continue
    }

    $itemNumber = 1

    foreach ($sectionItem in $sectionItems) {
        if ($sectionItems.Count -gt 1) {
            $txtReportLines += ""
            $txtReportLines += "Item $itemNumber"
            $txtReportLines += ("-" * 30)
        }

        if ($sectionItem -is [System.Collections.IDictionary]) {
            foreach ($key in $sectionItem.Keys) {
                $value = $sectionItem[$key]

                if (
                    $null -eq $value -or
                    [string]::IsNullOrWhiteSpace([string]$value)
                ) {
                    $value = "Not available"
                }
                elseif (
                    $value -is [System.Collections.IEnumerable] -and
                    $value -isnot [string]
                ) {
                    $value = @($value) -join ", "
                }

                $txtReportLines += (
                    "{0,-30}: {1}" -f $key, $value
                )
            }
        }
        else {
            $properties = @(
                $sectionItem.PSObject.Properties |
                    Where-Object {
                        $_.MemberType -in @(
                            "NoteProperty",
                            "Property",
                            "AliasProperty"
                        )
                    }
            )

            if ($properties.Count -eq 0) {
                $txtReportLines += [string]$sectionItem
            }
            else {
                foreach ($property in $properties) {
                    $value = $property.Value

                    if (
                        $null -eq $value -or
                        [string]::IsNullOrWhiteSpace([string]$value)
                    ) {
                        $value = "Not available"
                    }
                    elseif (
                        $value -is [System.Collections.IEnumerable] -and
                        $value -isnot [string]
                    ) {
                        $value = @($value) -join ", "
                    }

                    $txtReportLines += (
                        "{0,-30}: {1}" -f
                        $property.Name,
                        $value
                    )
                }
            }
        }

        $itemNumber++
    }
}

# ============================================================
# ADD DISPLAY, BATTERY, NETWORK, AND WARNING SECTIONS
# ============================================================

$remainingSectionsToAdd = @(
    @{
        Title = "DISPLAY INFORMATION"
        Data  = $script:AuditData["Monitors"]
    },
    @{
        Title = "BATTERY INFORMATION"
        Data  = $script:AuditData["Batteries"]
    },
    @{
        Title = "NETWORK INFORMATION"
        Data  = $script:AuditData["Networks"]
    }
)

foreach ($remainingSection in $remainingSectionsToAdd) {
    $txtReportLines += ""
    $txtReportLines += "----------------------------------------------------------------------"
    $txtReportLines += $remainingSection.Title
    $txtReportLines += "----------------------------------------------------------------------"

    $sectionData = $remainingSection.Data

    if ($null -eq $sectionData) {
        $txtReportLines += "Information not available."
        continue
    }

    $sectionItems = @($sectionData)

    if ($sectionItems.Count -eq 0) {
        $txtReportLines += "None detected."
        continue
    }

    $itemNumber = 1

    foreach ($sectionItem in $sectionItems) {
        if ($sectionItems.Count -gt 1) {
            $txtReportLines += ""
            $txtReportLines += "Item $itemNumber"
            $txtReportLines += ("-" * 30)
        }

        $properties = @(
            $sectionItem.PSObject.Properties |
                Where-Object {
                    $_.MemberType -in @(
                        "NoteProperty",
                        "Property",
                        "AliasProperty"
                    )
                }
        )

        if ($properties.Count -eq 0) {
            $txtReportLines += [string]$sectionItem
        }
        else {
            foreach ($property in $properties) {
                $value = $property.Value

                if (
                    $null -eq $value -or
                    [string]::IsNullOrWhiteSpace([string]$value)
                ) {
                    $value = "Not available"
                }
                elseif (
                    $value -is [System.Collections.IEnumerable] -and
                    $value -isnot [string]
                ) {
                    $value = @($value) -join ", "
                }

                $txtReportLines += (
                    "{0,-30}: {1}" -f
                    $property.Name,
                    $value
                )
            }
        }

        $itemNumber++
    }
}

$txtReportLines += ""
$txtReportLines += "----------------------------------------------------------------------"
$txtReportLines += "AUTOMATED AUDIT WARNINGS"
$txtReportLines += "----------------------------------------------------------------------"

$auditWarningItems = @($script:AuditData["AuditWarnings"])

if ($auditWarningItems.Count -eq 0) {
    $txtReportLines += "No automated audit warnings were found."
}
else {
    $warningNumber = 1

    foreach ($auditWarning in $auditWarningItems) {
        $txtReportLines += (
            "{0}. {1}" -f
            $warningNumber,
            $auditWarning
        )

        $warningNumber++
    }
}

$txtReportLines += ""
$txtReportLines += "----------------------------------------------------------------------"
$txtReportLines += "FINAL AUDIT STATUS"
$txtReportLines += "----------------------------------------------------------------------"

$txtReportLines += (
    "{0,-30}: {1}" -f
    "Warnings Found",
    $warningCount
)

$txtReportLines += (
    "{0,-30}: {1}" -f
    "Overall Audit Status",
    $overallAuditStatus
)

$txtReportLines += (
    "{0,-30}: {1}" -f
    "Summary",
    $overallAuditMessage
)

$txtReportLines += ""
$txtReportLines += "======================================================================"
$txtReportLines += "END OF REPORT"
$txtReportLines += "======================================================================"

try {
    $txtReportLines | Set-Content -Path $txtReportPath -Encoding UTF8 -ErrorAction Stop

    Write-Host ""
    Write-SectionHeader -Title "TXT REPORT EXPORT"

    Write-Field -Label "Export Status" -Value "Successful"
    Write-Field -Label "TXT Report" -Value $txtReportPath
}
catch {
    Write-Host ""
    Write-SectionHeader -Title "TXT REPORT EXPORT"

    Write-Host "Unable to create the TXT report." -ForegroundColor Red
    Write-Host $_.Exception.Message -ForegroundColor Red
}

Write-SectionHeader -Title "SCAN COMPLETE"

Write-Host "The core device and monitor scan completed successfully." `
    -ForegroundColor Green

Write-Host ""
Write-Host "Monitor features now included:" -ForegroundColor Cyan
Write-Host "- Connected display count"
Write-Host "- Monitor manufacturer"
Write-Host "- Monitor model"
Write-Host "- Monitor serial number"
Write-Host "- Manufacture week and year"
Write-Host "- Approximate screen size"
Write-Host "- Active display status"
Write-Host "- Safe handling when monitor data is unavailable"
Write-Host ""

Read-Host "Press Enter to close"  








    


    

    

    

    
    


